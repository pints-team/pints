import numpy as np
import theano
from scipy.integrate import odeint
import pints
from theano.tests import unittest_tools as utt
from theano import config
theano.config.exception_verbosity= 'high'

class FitzhughNagumoModel(pints.ForwardModel):
    

    def __init__(self, y0=None):
        super(FitzhughNagumoModel, self).__init__()

        # Check initial values
        if y0 is None:
            self._y0 = np.array([-1, 1], dtype=float)
        else:
            self._y0 = np.array(y0, dtype=float)
            if len(self._y0) != 2:
                raise ValueError('Initial value must have size 2.')

    def n_parameters(self):
        """ See :meth:`pints.ForwardModel.n_parameters)`. """
        return 3

    def n_outputs(self):
        """ See :meth:`pints.ForwardModel.outputs()`. """
        return 2

    def simulate(self, parameters, times):
        return self._simulate(parameters, times, False)

    def simulate_with_sensitivities(self, parameters, times):
        return self._simulate(parameters, times, True)

    def _simulate(self, parameters, times, sensitivities):
        """ See :meth:`pints.ForwardModel.simulate()`. """
        a, b, c = [float(x) for x in parameters]

        times = np.asarray(times)
        if np.any(times < 0):
            raise ValueError('Negative times are not allowed.')

        def r(y, t, p):
            V, R = y
            dV_dt = (V - V**3 / 3 + R) * c
            dR_dt = (V - a + b * R) /-c
            return dV_dt, dR_dt

        if sensitivities:
            def jac(y):
                V, R = y
                ret = np.empty((2, 2))
                ret[0, 0] = c*(1-V**2)#(-3 * V**2 + 1)
                ret[0, 1] = c
                ret[1, 0] = -1 / c
                ret[1, 1] = -b / c
                return ret

            def dfdp(y):
                V, R = y
                ret = np.empty((2, 3))
                ret[0, 0] = 0
                ret[0, 1] = 0
                ret[0, 2] = R - V**3/3 + V
                ret[1, 0] = 1 / c
                ret[1, 1] = -R / c
                ret[1, 2] = (R * b + V - a) / c**2
                return ret

            def rhs(y_and_dydp, t, p):
                y = y_and_dydp[0:2]
                dydp = y_and_dydp[2:].reshape((2, 3))

                dydt = r(y, t, p)
                d_dydp_dt = np.matmul(jac(y), dydp) + dfdp(y)

                return np.concatenate((dydt, d_dydp_dt.reshape(-1)))

            y0 = np.zeros(8)
            y0[0:2] = self._y0
            result = odeint(rhs, y0, times, (parameters,))
            values = result[:, 0:2]
            dvalues_dp = result[:, 2:].reshape((len(times), 2, 3))
            return values, dvalues_dp
        else:
            values = odeint(r, self._y0, times, (parameters,))
            return values
model = FitzhughNagumoModel()

def forwardModel(params):
    times = np.linspace(0, 20, 40)
    values = model.simulate_with_sensitivities(params, times)[0]
    jac = model.simulate_with_sensitivities(params, times)[1].reshape((2*len(times),len(params)))
    
    return np.array(values,dtype=np.float64), np.array(jac,dtype=np.float64)


class OpWrapper(theano.Op):

    def __init__(self, f, jac_f):
        self.f = f
        self.jac_f = jac_f

    def make_node(self, x):
        x = theano.tensor.as_tensor_variable(x)
        return theano.Apply(self, [x], [x.type()])

    def perform(self, node, inputs_storage, output_storage):
        x = inputs_storage[0]
        out = output_storage[0]
        # `x` and `out` are arrays, so we can evaluate using `self.f`
        out[0] = np.asarray(self.f(x))

    def grad(self, inputs, output_grads):
        # `x` and `v` are symbolic here
        x = inputs[0]
        v = output_grads[0]

        op = self

        class OpGradWrapper(theano.Op):
            def __init__(self):
                pass

            def make_node(self, x, v):
                x = theano.tensor.as_tensor_variable(x)
                v = theano.tensor.as_tensor_variable(v)
                node = theano.Apply(self, [x, v], [v.type()])
                return node

            def perform(self, node, inputs_storage, output_storage):
                x = inputs_storage[0]
                v = inputs_storage[1]
                out = output_storage[0]
                out[0] = np.asarray(op.jac_f(x, v))

        grad_op = OpGradWrapper()
        grad_op_apply = grad_op(x, v)
        
        
        return [grad_op_apply]
def f(x):
    
    forProp = forwardModel(np.array(x,dtype=np.float64))[0]
    return forProp.reshape(2*len(forProp),)

def jac_f(x, v):
    
    backProp = forwardModel(np.array(x,dtype=np.float64))[1]
    return backProp.T.dot(v)


class test_Double(utt.InferShapeTester):
    def setUp(self):
        super(test_Double, self).setUp()
        self.op_class = OpWrapper
        self.op = OpWrapper(f, jac_f)

    def test_basic(self):
        x = theano.tensor.vector()
        fth = theano.function([x], self.op(x))
        inp = np.asarray(np.array([0.2,0.2,3.0]), dtype=config.floatX)
        out = fth(inp)
        # Compare the result computed to the expected value.
        utt.assert_allclose(f(inp), out)
    def test_grad(self):
        theano.tests.unittest_tools.verify_grad(self.op,
                                            [np.array([0.2,0.2,3.0])])


