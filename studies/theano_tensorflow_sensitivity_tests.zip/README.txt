To run test in Theano:

command:
theano-nose test_pintsTheanoModelSens.py

